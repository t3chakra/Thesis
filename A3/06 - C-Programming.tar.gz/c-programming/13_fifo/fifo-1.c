#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define FIFO_NAME_LEN	10
#define NUM_CHARS_TO_WRITE	15

char *
randStr(int size)
{
    int fd = -1, i;
    unsigned char *ret;

    ret = (char *)calloc(size+1, sizeof(unsigned char));
    ret[size] = '\0';

    if((fd = open("/dev/urandom", O_RDONLY)) < 0) {
	perror("open(/dev/urandom)");
	exit(0);
    }

    if(read(fd, ret, size) < 1) {
	fprintf(stderr, "read() returned < size\n");
	exit(0);
    }

    close(fd);

    for(i = 0; i < size; i++) {
	ret[i] = (ret[i] % ('z' - 'a')) + 'a';
    }

    return ((char *)ret);
}

int
main(int argc, char *argv[])
{
    /* Randomly create fifo name */
    const int fifoNameLen = strlen("/tmp/") + FIFO_NAME_LEN + 1;
    char fifoName[fifoNameLen];
    char *randName;

    strcpy(fifoName, "/tmp/");
    randName = randStr(FIFO_NAME_LEN);
    strcpy(fifoName + strlen("/tmp/"), randName);
    free(randName);

    printf("[%s] fifoName: %s\n", argv[0], fifoName); fflush(stdout);

    if(mkfifo(fifoName, S_IRUSR | S_IWUSR) < 0) {
	perror("mkfifo"); return 0;
    }

    /* Fifo has been created. Write to it */
    int fifo_fd = open(fifoName, O_WRONLY);

    if(fifo_fd < 0) {
	perror("open(fifo)"); return 0;
    }

    char *charsToWrite = randStr(NUM_CHARS_TO_WRITE);

    printf("[%s] writing %s to fifo...\n", argv[0], charsToWrite);
    fflush(stdout);

    if(write(fifo_fd, charsToWrite, NUM_CHARS_TO_WRITE + 1) < 0) {
	perror("write"); return 0;
    }

    free(charsToWrite);
    close(fifo_fd);

    if(unlink(fifoName) < 0) {
	perror("unlink");
    }

    return 0;
}
