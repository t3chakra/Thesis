#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

#define FIFO_NAME_LEN	10
#define NUM_CHARS_TO_WRITE	5

int
main(int argc, char *argv[])
{
    char *fifoName = NULL;

    if(argc < 2) {
	fprintf(stderr, "fifo name needed as (first) argument.\n"); return 0;
    }

    fifoName = argv[1];

    int fifo_fd = open(fifoName, O_RDONLY);

    if(fifo_fd < 0) {
	perror("open(fifo)"); return 0;
    }

    char c;

    printf("[%s] reading... ", argv[0]); fflush(stdout);
    for(c = 'a'; c != '\0'; ) {
	if(read(fifo_fd, &c, 1) < 1) {
	    fprintf(stderr, "error: read < 1 char from fifo.\n"); return 0;
	}

	printf("%c", c); fflush(stdout);
    }

    printf(" done\n"); fflush(stdout);

    close(fifo_fd);

    return 0;
}
